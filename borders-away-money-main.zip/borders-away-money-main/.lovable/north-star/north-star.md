<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Pessoas no exterior recebem o dinheiro que familiares e amigos enviam para elas.

## Métrica

Envios confirmados após o pagamento com cartão a cada mês
